import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";
import spec from "./openapi.json";
import type { components } from "./generated";
export type Schemas = components["schemas"];
const ajv = new Ajv2020({
  strict: false,
  allErrors: true,
  validateFormats: true,
});
addFormats(ajv);
ajv.addSchema({ ...spec, $id: "crm-contract" });
export function validate<N extends keyof Schemas>(
  name: N,
  value: unknown,
): value is Schemas[N] {
  return !!ajv.validate(
    { $ref: `crm-contract#/components/schemas/${name}` },
    value,
  );
}
export function parse<N extends keyof Schemas>(
  name: N,
  value: unknown,
): Schemas[N] {
  if (!validate(name, value))
    throw new Error(`Invalid ${name}: ${ajv.errorsText()}`);
  return value;
}
export { spec };

export * from "./weekly";
