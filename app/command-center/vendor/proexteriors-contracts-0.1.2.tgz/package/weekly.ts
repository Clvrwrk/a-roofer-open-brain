import Ajv2020 from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';
import weeklySpec from './weekly.json';
export type WeeklyException={reason:string;owner_id:string;due_date:string};
export type WeeklyReport={no_change:boolean;progress:string;collection_status:'unknown'|'no_change'|'promise'|'dispute'|'reported_payment'|'insurance_pending';expected_amount_minor:number|null;expected_date:string|null;basis:string;confidence:'unknown'|'low'|'medium'|'high';blocker:string|null;next_action:string;next_action_date:string;evidence_ids:string[];exception:WeeklyException|null};
export type WeeklySource={contract_key:string;property_id:string|null;effort_id:string|null;owner_id:string|null;office_id:string;currency:'USD';contract_balance_minor:number|null;billed_ar_minor:number|null;unbilled_minor:number|null;as_of:string;source_revision:string;source_refs:string[];closed:boolean;inclusion_reason:string};
export type WeeklyCommand={expected_version:number}&(
 | {operation:'review';item_id:string;report:WeeklyReport}
 | {operation:'submit';rep_id:string;delegation_reason:string|null}
 | {operation:'ops';item_id:string;decision:'accept'|'return';note:string}
 | {operation:'attest';item_id:string;kind:'accounting'|'operations';note:string}
 | {operation:'finalize';note:string});
export type WeeklyReceipt={event_id:string;cycle_id:string;cycle_version:number;item_version:number|null;accepted_at:string;outbox_id:string;snapshot_id:string|null};
export type WeeklyItem={accounting_note?:string|null;friday_ops_note?:string|null;ops_note?:string|null;property_label?:string|null;id:string;version:number;source:WeeklySource;report_id:string|null;report:WeeklyReport|null;sales_submitted:boolean;ops_decision:'accept'|'return'|null;ops_actor_id:string|null;accounting_actor_id:string|null;friday_ops_actor_id:string|null};
export type WeeklyPage={cycle_id:string;cycle_version:number;population_version:number;coverage_complete:boolean;total:number;items:WeeklyItem[];next_cursor:string|null};
export type WeeklyCycle={id:string;week_friday:string;version:number;population_version:number;state:'open'|'amending'|'finalized'|'finalized_with_exceptions';coverage_complete:boolean;visible_required:number;visible_submitted:number};
export type WeeklyCycleList={cycles:WeeklyCycle[];next_before:string|null};
export type WeeklySnapshotSummary={id:string;report_version:number;created_at:string};
export type WeeklySnapshotList={cycle_id:string;snapshots:WeeklySnapshotSummary[];next_before:number|null};
export type WeeklySnapshotPage={cycle_id:string;snapshot_id:string;report_version:number;created_at:string;access_basis:'current_access';scope_token:string;visible_total:number;items:WeeklyItem[];next_cursor:string|null};
export type WeeklySubmissionSummary={id:string;actor_id:string;accepted_at:string;on_time:boolean;with_exceptions:boolean;delegation_reason:string|null;current:boolean};
export type WeeklyParticipant={rep_id:string;display_name:string|null;active:boolean;office_id:string;timezone:string;sales_deadline:string;required:number;reviewed:number;returned:number;exceptions:number;latest_submission:WeeklySubmissionSummary|null;status:'source_incomplete'|'assignment_inactive'|'returned'|'submitted'|'submitted_with_exceptions'|'needs_resubmission'|'ready'|'in_progress';can_submit:boolean;overdue:boolean};
export type WeeklyParticipationPage={cycle_id:string;cycle_version:number;coverage_complete:boolean;viewer_id:string;capabilities:string[];scope_token:string;visible_total:number;participants:WeeklyParticipant[];next_cursor:string|null};
export type WeeklyReviewContext={cycle_id:string;cycle_version:number;item_id:string|null;item_version:number|null;actions:('review'|'ops_accept'|'ops_return'|'accounting_attest'|'operations_attest')[];can_finalize:boolean};
type WeeklySchemas={WeeklyReviewContext:WeeklyReviewContext;WeeklyParticipationPage:WeeklyParticipationPage;WeeklyCycleList:WeeklyCycleList;WeeklySnapshotList:WeeklySnapshotList;WeeklySnapshotPage:WeeklySnapshotPage;WeeklyCommand:WeeklyCommand;WeeklyReceipt:WeeklyReceipt;WeeklyItem:WeeklyItem;WeeklyPage:WeeklyPage;WeeklyCycle:WeeklyCycle;WeeklySource:WeeklySource;WeeklyReport:WeeklyReport};
const ajv=new Ajv2020({strict:false,allErrors:true});addFormats(ajv);ajv.addSchema({...weeklySpec,$id:'weekly-contract'});
export function parseWeekly<N extends keyof WeeklySchemas>(name:N,value:unknown):WeeklySchemas[N]{
 if(!ajv.validate({$ref:`weekly-contract#/components/schemas/${name}`},value))throw Error(`Invalid ${name}: ${ajv.errorsText()}`);
 return value as WeeklySchemas[N];
}
