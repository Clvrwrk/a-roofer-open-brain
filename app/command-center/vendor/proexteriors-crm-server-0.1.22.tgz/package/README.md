# Pro Exteriors canonical CRM server

Server-only HTTP dispatch, scoped Supabase RPC client and CSRF binding shared by CRM and Command Center. Requires Node22 and the pinned contracts package. Never import from a browser component.

Hosts supply explicit enable/config/public-origin and a per-request session established by verified staff middleware. `createCrmStaffSession` consumes an already verified WorkOS identity; it checks token/identity continuity and creates a host/session-bound CSRF token. It is not a signature verifier. Supabase verifies the forwarded JWT and canonical RPCs resolve current membership/capabilities/row scope. Browser bearer/role headers are never accepted as staff authority.

No service-role credentials, provider writes, automatic retries, raw SQL response forwarding or legacy data fallback. Feature flags default off. WorkOS issuer integration and authenticated-role JWT template must be verified on the intended Supabase branch before activation. Missing routes remain unavailable until implemented.
