# Pro Exteriors shared sales workspace

Private, immutable package for Astro/Vite React consumers. Exports compiled ESM and declarations so host SSR and hydration use the same package artifact. Run `npm run build:sales` before packing or after changing shared sources. React is a peer; never bundle a second React runtime. Contract types come from the matching private contracts artifact.

Import `SalesWorkspace`, create one `createSalesClient({apiBase:"/api/sales"})` per mounted workspace, and import `@proexteriors/sales-workspace/styles.css`. The host React wrapper supplies the client; do not serialize a client object through an Astro island. Set `embedded` inside Command Center's existing shell. Session/API routes remain same-origin and must enforce current staff scope and CSRF server-side.

Practice mode defaults off. The host can opt into a visibly synthetic workspace with `practice`; it is not authorization to expose practice routes or real data. Offline controls are absent unless the host supplies `{href,save}`. This package does not install service workers, open IndexedDB or import provider/server adapters. Host responses supply their own signed launch/download/upload URLs. Additional HTTPS upload origins require explicit host configuration; arbitrary ticket headers and redirect following are refused.

Scoped styles are generated from the canonical design primitives and feature layout using `npm run build:sales-styles`. Change source, regenerate and verify; do not hand-edit generated styles. Same tokens/font package must be installed on both consumers. The CSS namespace protects unrelated Command Center surfaces; hosted parity still requires browser evidence.
